from database import add_update

message = input("Enter the update message to send to users: ")
add_update(message)
print("Update added. It will be sent in the next cycle.")
