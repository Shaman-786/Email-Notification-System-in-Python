import sqlite3

def create_tables():
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS updates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT NOT NULL,
        sent INTEGER DEFAULT 0
    )
    """)

    conn.commit()
    conn.close()

def get_users():
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("SELECT name, email FROM users")
    users = cur.fetchall()
    conn.close()
    return users

def get_unsent_updates():
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("SELECT id, message FROM updates WHERE sent = 0")
    updates = cur.fetchall()
    conn.close()
    return updates

def mark_update_sent(update_id):
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("UPDATE updates SET sent = 1 WHERE id = ?", (update_id,))
    conn.commit()
    conn.close()

def add_user(name, email):
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (name, email) VALUES (?, ?)", (name, email))
    conn.commit()
    conn.close()

def add_update(message):
    conn = sqlite3.connect("database.db")
    cur = conn.cursor()
    cur.execute("INSERT INTO updates (message) VALUES (?)", (message,))
    conn.commit()
    conn.close()
