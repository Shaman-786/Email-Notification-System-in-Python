from database import create_tables, get_users, get_unsent_updates, mark_update_sent
from email_sender import send_email

def notify_users():
    users = get_users()
    updates = get_unsent_updates()

    for update_id, message in updates:
        for name, email in users:
            subject = "New Update Notification"
            content = f"Dear {name},\n\n{message}\n\nBest regards,\nTeam"
            try:
                send_email(email, subject, content)
                print(f"Email sent to {email}")
            except Exception as e:
                print(f"Failed to send to {email}: {str(e)}")

        mark_update_sent(update_id)

if __name__ == "__main__":
    create_tables()
    notify_users()
