# Email Configuration
EMAIL_ADDRESS = "youremail@example.com"
EMAIL_PASSWORD = "your-app-password"
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
